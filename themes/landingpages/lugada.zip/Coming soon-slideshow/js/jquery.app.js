/* Theme Name: Lugada - Landing page Template
   Author: Coderthemes
   Author e-mail: coderthemes@gmail.com
   Version: 1.0.0
   Created:Jun 2015
   File Description:Main JS file of the template
*/

/*-------------------------------------------------*/
/* =  Full-window section
/*-------------------------------------------------*/

var windowHeight = $(window).height(),
topSection = $('.home-fullscreen');
topSection.css('height', windowHeight);

$(window).resize(function(){
var windowHeight = $(window).height();
topSection.css('height', windowHeight);
});
/* ==============================================
Preloader
=============================================== */

$(window).load(function() {
    $('.status').fadeOut();
    $('.preloader').delay(350).fadeOut('slow');
});

